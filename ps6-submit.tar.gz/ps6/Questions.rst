
Questions
=========

Norm
----

* Look through the code for ``run()`` in ``norm_utils.hpp``.  How are we setting the number of threads for OpenMP to use?
A for loop is used to iterate over i = 1, 2, 4, 8, etc., and for each iteration we use the member function omp_set_num_threads(i) to modify the number of threads to use.

* Which version of ``norm`` provides the best parallel performance?  How do the results compare to the parallelized versions of ``norm`` from ps5?
Overall, the block critical norm provided the best parallel performance. This is similar to what was seen in ps5 because block partitioning was also faster than cyclic partitioning in ps5. It seems that the
"reduction" norms have a lot of overhead relative to "critical" because for small problem sizes the reduction norms are much slower than the critical norms.

* Which version of ``norm`` provides the best parallel performance for larger problems (i.e., problems at the top end of the default sizes in the drivers or larger)?  How do the results compare to the parallelized versions of ``norm`` from ps5?
For large problems, the cyclic reduction norm had the best performance, although it was just barely faster than block reduction. It seems that reduction is faster than critical for sufficiently large problems in which the relative cost of overhead
becomes negligible. In ps5 we saw that block partitioning was faster than cyclic partitioning for all problem sizes, so it's unclear why cyclic is comparably fast here.

* Which version of ``norm`` provides the best parallel performance for small problems (i.e., problems smller than the low end of the default sizes in the drivers)?  How do the results compare to the parallelized versions of ``norm`` from ps5?  
For small problems, both block critical norm provided the best performance. Similar to ps5, it's clear that block partitioning is faster than cyclic partitioning for small problems due to accessing the vector entries in sequence instead of out of order.
It is also evident that reduction has a higher overhead than critical norms, which is largely why reduction is much slower than critical for small problems.

Sparse Matrix-Vector Product
----------------------------

* How does ``pmatvec.cpp`` set the number of OpenMP threads to use?
Similar to norm_utils.hpp, a for loop is used and the member function omp_set_num_threads(i) is used to modify the number of threads to use.

* (For discussion on Piazza.)
What characteristics of a matrix would make it more or less likely to exhibit an error 
if improperly parallelized?  Meaning, if, say, you parallelized ``CSCMatrix::matvec`` with just basic  columnwise partitioning -- there would be potential races with the same locations in ``y`` being read and written by multiple threads.  But what characteristics of the matrix give rise to that kind of problem?  Are there ways to maybe work around / fix that if we knew some things in advance about the (sparse) matrix?
For CSR and CSC matrices that are improperly parallelized, race conditions are more likely to occur because row and column indices contain repeated values that may be partitioned to different threads. So if a CSR matrix is partitioned by columns, the row indices will be partitioned and thus repeated indices may be used by separate threads in parallel. This would result in a race condition as separate threads try to update
the same y element at the same time. Thus for CSR matrices, a sparse matrix in which there are few nonzero values for each row this is less likely, while a sparse matrix with a lot of entries in a few rows would have a high likelihood of race conditions.

* Which methods did you parallelize?  What directives did you use?  How much parallel speedup did you see for 1, 2, 4, and 8 threads?
I parallelized CSR::matvec and CSC::t_matvec using "#pragma omp parallel for". For CSR::matvec I saw 1.8x, 2.6x, and 2.6x speedup for 2, 4, and 8 threads, respectively. For CSC::t_matvec I saw 1.5x, 2x, and 2x speedup for 2, 4, and 8 threads, respectively.


Sparse Matrix Dense Matrix Product (AMATH583 Only)
--------------------------------------------------


* Which methods did you parallelize?  What directives did you use?  How much parallel speedup did you see for 1, 2, 4, and 8 threads?  How does the parallel speedup compare to sparse matrix by vector product?


PageRank Reprise
----------------

* Describe any changes you made to pagerank.cpp to get parallel speedup.  How much parallel speedup did you get for 1, 2, 4, and 8 threads?
I modified line 72 to "CSCMatrix A = read_cscmatrix(input_file);" such that a CSC matrix is read in instead of a CSR matrix, which utilizes the parallelization of CSC::t_matvec.
Doing this provided about 33%, 50%, and 50% increased performance for 2, 4, and 8 threads, respectively.

* (EC) Which functions did you parallelize?  How much additional speedup did you achieve?


Load Balanced Partitioning with OpenMP (Extra Credit)
-----------------------------------------------------

* Are there any choices for scheduling that make an improvement in the parallel performance (most importantly, scalability) of pagerank?